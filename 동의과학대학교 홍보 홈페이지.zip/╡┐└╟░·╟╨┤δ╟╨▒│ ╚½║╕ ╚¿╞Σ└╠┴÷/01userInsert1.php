<?php

include "00DBConnect1.php";

$regdate = date("Y-m-d H:i:s");
$user_name = $_POST["user_name"];
$user_pw = $_POST["user_pw"];

$query	= "INSERT INTO `register_member` (
		`user_id`,
		`user_category`,
        `id`,
		`user_name`,
		`user_phone`,
		`user_email`,
		`user_pw`,
		`user_regdate`
		) VALUES (".
		"NULL, '".
		$_POST["user_category"] . "', '".
        $_POST["id"] . "', '".
		$user_name . "', '".
		$_POST["user_phone"] . "', '".
		$_POST["user_email"] . "', '".
		$_POST["user_pw"] . "', '".
		$regdate . "'" .
		")";

$result = mysqli_query($dbConn, $query);

if($result){
	$query = "SELECT `user_id`
		FROM `register_member`
		WHERE
		`user_name` = '" . $user_name . "' AND `user_regdate` = '" . $regdate . "'";
	$user_id = mysqli_fetch_array(mysqli_query($dbConn, $query));

	session_start();

	$_SESSION["user_id"] = $user_id[0];
	$_SESSION["user_name"] = $user_name;

	 header("Location: advertisement.html");

} else {
	echo "<html><body onload='document.form1.submit();'>";
	echo "<form name='form1' method='post' action='advertisement.html'>";
	echo "<input type='hidden' name='result' value='fail'>";
	echo "</form></body></html>";
}

// DB 연결종료
mysqli_close($dbConn);

?>
